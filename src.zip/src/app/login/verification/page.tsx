export default function Verification() {
  return (
    <>
      <div>
        <button>send the email again.</button>
      </div>
    </>
  );
}
