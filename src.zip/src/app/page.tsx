export default function Home() {
  return (
    <div className="w-full h-svh">
      <div className="flex justify-center">
        <div>
          <div>
            <a href="/login">Login</a>
          </div>
          <div>SignUp</div>
        </div>
      </div>
    </div>
  );
}
