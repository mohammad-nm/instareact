import { NextApiHandler, NextRequest } from "next";
export const handler = (req:NextApiHandler, res:NextRequest);
