export const getLLToken = async (SLToken: string) => {
  try {
    const response = await fetch(`https://graph.instagram.com/access_token`, {
      method: "GET",
      body: {
        grant_type: "ig_exchange_token",
        client_secret: process.env.NEXT_PUBLIC_INSTAGRAM_CLIENT_SECRET!,
        access_token: SLToken,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data.error.message || "Failed to retrieve long-lived access token"
      );
    }
    if (response.ok) {
      console.log("LLToken fetched!", data);
      return data;
    }
  } catch (error) {
    console.error("Error exchanging for long-lived token:", error);
    throw error;
  }
};
