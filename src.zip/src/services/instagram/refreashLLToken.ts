export const refreashLLToken = async (LLToken: string) => {
  try {
    const response = await fetch(
      "https://graph.instagram.com/refresh_access_token",
      {
        method: "GET",
        body: {
          grant_type: "ig_refresh_token",
          access_token: LLToken,
        },
      }
    );

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error_message);
    }
  } catch (error) {}
};
